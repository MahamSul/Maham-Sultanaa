import { describe, expect, it } from 'vitest';
import { projects, services } from '@/lib/portfolio';

describe('Service examples', () => {
  it('includes exactly two AI projects without live-project destinations', () => {
    const ai = projects.filter(project => project.concept);
    expect(ai.map(project => project.name)).toEqual(['AI Marketing Studio', 'AI Knowledge Assistant']);
    for (const project of ai) {
      expect(project.category).toBe('AI integrations');
      expect(project.url).toBe('');
    }
    expect(projects.filter(project => !project.concept && project.url.startsWith('https://'))).toHaveLength(4);
  });

  it('names the real estate project Homiq, never all caps', () => {
    expect(projects.some(project => project.name === 'Homiq Real Estate')).toBe(true);
    expect(projects.some(project => project.name.includes('HOMIQ'))).toBe(false);
    expect(services.some(service => service.example === 'Homiq Real Estate')).toBe(true);
  });

  it('never uses the word concept in any project text shown to visitors', () => {
    for (const project of projects) {
      const visible = [project.name, project.label, project.description, project.challenge, project.solution, ...project.features, ...project.tags].join(' ').toLowerCase();
      expect(visible).not.toContain('concept');
    }
  });

  it('does not label an existing portfolio project as an AI implementation', () => {
    const ai = services.find(service => service.label === 'AI integrations');
    expect(ai).toBeDefined();
    expect(ai?.example).toBeNull();
  });

  it('resolves every supplied service example to an actual project', () => {
    const examples = services.flatMap(service => service.example ? [service.example] : []);
    expect(examples.length).toBe(4);
    for (const example of examples) {
      expect(projects.some(project => project.name === example)).toBe(true);
    }
  });
});
