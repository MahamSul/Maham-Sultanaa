import { createFileRoute, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { ArrowUpRight, Code2, Server, Database, Cloud, Plug } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import portrait from '@/assets/maham-sultana.asset.json';
import { ExpertiseSection } from '@/components/portfolio/expertise';
import { InquirySection } from '@/components/portfolio/inquiry-section';
import { portfolioHead, projects, technicalStack } from '@/lib/portfolio';

export const Route = createFileRoute('/')({ head: () => {
  const head = portfolioHead('Maham Sultana — Full Stack Web, CRM & SaaS Developer', 'Explore Maham Sultana’s custom CRM, SaaS and business web applications, API automation and OpenAI integrations, from TypeScript interfaces to cloud deployment.');
  return portrait.url.startsWith('https://') ? { ...head, meta: [...head.meta, { property: 'og:image', content: portrait.url }, { name: 'twitter:image', content: portrait.url }] } : head;
}, component: Index });
function Index() {
  const [filter, setFilter] = useState('All work');
  const [selected, setSelected] = useState<(typeof projects)[number] | null>(null);
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const update = () => { const height = document.documentElement.scrollHeight - window.innerHeight; setProgress(height > 0 ? window.scrollY / height : 0); };
    window.addEventListener('scroll', update, { passive: true }); update();
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('revealed'); observer.unobserve(entry.target); } }), { threshold: 0.08 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    return () => { window.removeEventListener('scroll', update); observer.disconnect(); };
  }, []);
  const skillIcons = [Code2, Server, Database, Cloud, Plug];
  const visible = filter === 'All work' ? projects : projects.filter(project => project.category === filter);
  return <>
    <div className="reading-progress" style={{ transform: `scaleX(${progress})` }} />
    <section id="home" className="hero-section">
      <div className="page-width hero-grid"><div className="hero-copy entry">
        <p className="mono-label text-accent">MAHAM SULTANA · FULL-STACK DEVELOPER</p>
        <h1 className="hero-title">Full-stack web apps,<br />CRM & SaaS development.</h1>
        <p className="hero-subtitle">Custom CRM systems, SaaS platforms and business web applications — with connected APIs, workflow automation and practical AI integrations.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Button asChild variant="portfolio" size="lg"><Link to="/" hash="projects">Explore my work <ArrowUpRight /></Link></Button><Button asChild variant="portfolioOutline" size="lg"><Link to="/" hash="contact">Discuss a project <ArrowUpRight /></Link></Button></div>
        <div className="hero-person"><img src={portrait.url} alt="Maham Sultana" /><div><strong>Maham Sultana</strong><span>Full-stack development · CRM · SaaS · AI integrations</span></div></div>
      </div>
      </div>
    </section>
    <ExpertiseSection />
    <section id="projects" className="work-band"><div className="page-width section"><div className="section-top reveal"><div><p className="eyebrow mb-4 text-primary">02 / SELECTED WORK</p><h2 className="section-heading">Projects <span className="text-primary">in action.</span></h2></div><p className="text-sm text-muted-foreground">Business applications & AI integrations.</p></div>
      <div className="filter-row" aria-label="Filter projects">{['All work', ...new Set(projects.map(p => p.category))].map(f => <Button key={f} variant="ghost" className={filter === f ? 'filter-active' : ''} onClick={() => setFilter(f)} aria-pressed={filter === f}>{f}{f === 'All work' && <span className="filter-count">{String(projects.length).padStart(2, '0')}</span>}</Button>)}</div>
      <div className="project-showcase">{visible.map((p, i) => <article className="work-item" key={p.name}><Button variant="ghost" className={`work-preview ${p.color}`} onClick={() => setSelected(p)} aria-label={`Preview ${p.name}`}><img src={p.image} alt={`${p.name} application screenshot`} loading="lazy" /><span className="preview-label">Take a closer look <ArrowUpRight size={16} /></span></Button><div className="work-description"><span className="work-number">0{i+1}</span><div className="mt-5 flex items-start justify-between gap-4"><div><p className="eyebrow text-muted-foreground">{p.label}</p><h3 className="mt-2 text-2xl font-semibold">{p.name}</h3></div>{!p.concept && <Button asChild variant="outline" size="icon" className="rounded-full"><a href={p.url} target="_blank" rel="noopener noreferrer" aria-label={`Open ${p.name} live project`}><ArrowUpRight /></a></Button>}</div><p className="mt-3 text-sm leading-7 text-muted-foreground">{p.description}</p><div className="mt-4 flex flex-wrap gap-2">{p.tags.map(t => <span className="tag" key={t}>{t}</span>)}</div><Button variant="link" className="mt-5 px-0" onClick={() => setSelected(p)}>View case study <ArrowUpRight /></Button></div></article>)}</div>
    </div></section>
    <section id="about" className="about-band"><div className="page-width section"><p className="eyebrow mb-6">03 / YOUR DEVELOPER, FROM START TO FINISH</p><div className="about-layout reveal"><img className="about-portrait" src={portrait.url} alt="Maham Sultana, full-stack developer" loading="lazy" /><div className="about-copy"><h2 className="section-heading">One developer.<br /><span className="text-accent">The complete picture.</span></h2><p className="text-xl leading-9">Hi, I’m Maham. I build both sides of your product: the experience people see, and the systems that make it work.</p><p className="mt-6 text-sm leading-7 text-inverse-muted">I’m a full-stack web developer focused on CRM and SaaS applications. My work spans healthcare, real estate, team productivity, and lead management — from TypeScript interfaces and secure APIs to databases, cloud deployment, and OpenAI-powered features in existing systems.</p><div className="mt-8 flex flex-wrap gap-3">{['Custom CRM', 'Multi-tenant SaaS', 'Business web apps', 'AI integrations'].map(t => <span className="about-tag" key={t}>{t}</span>)}</div></div></div></div></section>
    <section className="skills-band" aria-labelledby="skills-heading"><div className="page-width section"><div className="skills-heading"><div><p className="eyebrow mb-3 text-accent">THE TECHNICAL STACK</p><h2 id="skills-heading" className="section-heading">From interface to infrastructure.</h2></div><p>The tools behind your product, connected from end to end.</p></div><div className="technical-stack" aria-label="Technical stack">{technicalStack.map((group, i) => { const Icon = skillIcons[i] ?? Code2; return <article className="skill-group" key={group.category}><div className="skill-group-heading"><Icon aria-hidden="true" /><h3>{group.category}</h3></div><ul>{group.tools.map(tool => <li key={tool}>{tool}</li>)}</ul></article>; })}</div></div></section>
    <section className="process-band" aria-labelledby="process-heading"><div className="page-width section"><p className="eyebrow mb-3">HOW I WORK</p><h2 id="process-heading" className="section-heading">A clear path from idea to product.</h2><div className="approach-grid">{[{ title: 'Understand first', description: 'The problem, the people, and the outcomes that matter.' }, { title: 'Build with intention', description: 'Clear interfaces. Cohesive logic. No unnecessary complexity.' }, { title: 'Think end to end', description: 'Every part of the experience belongs to the same story.' }].map((v, i) => <div key={v.title}><span className="process-number">0{i+1}</span><h3>{v.title}</h3><p>{v.description}</p></div>)}</div></div></section>
    <InquirySection />
    <Dialog open={selected !== null} onOpenChange={open => { if (!open) setSelected(null); }}><DialogContent className="max-h-[90dvh] w-[calc(100%-32px)] max-w-4xl overflow-y-auto">{selected && <><DialogTitle className="pr-8 text-2xl">{selected.name}</DialogTitle><DialogDescription>{selected.description}</DialogDescription><img className="mt-2 w-full rounded-md border border-border" src={selected.image} alt={`${selected.name} full application preview`} /><div className="case-grid"><div><p className="mono-label text-accent">CHALLENGE</p><p className="mt-2 text-sm">{selected.challenge}</p></div><div><p className="mono-label text-accent">SOLUTION</p><p className="mt-2 text-sm">{selected.solution}</p></div><div><p className="mono-label text-accent">KEY FEATURES</p><ul className="mt-2 flex flex-wrap gap-2">{selected.features.map(f => <li className="tag" key={f}>{f}</li>)}</ul></div><div><p className="mono-label text-accent">STACK</p><ul className="mt-2 flex flex-wrap gap-2">{(selected.proposedStack ?? ['React', 'Next.js', 'Node.js']).map(f => <li className="tag" key={f}>{f}</li>)}</ul></div></div><div className="flex flex-wrap items-center justify-between gap-4"><span className="text-sm text-muted-foreground">{selected.category}</span>{!selected.concept && <Button asChild variant="portfolio"><a href={selected.url} target="_blank" rel="noopener noreferrer">Visit live project <ArrowUpRight /></a></Button>}</div></>}</DialogContent></Dialog>
  </>;
}
