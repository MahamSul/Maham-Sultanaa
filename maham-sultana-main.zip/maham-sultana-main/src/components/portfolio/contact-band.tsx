import { Link } from '@tanstack/react-router';
import { ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
export function ContactBand() {
  return <section className="bg-secondary"><div className="page-width flex flex-col items-start justify-between gap-7 py-16 md:flex-row md:items-center"><div><p className="eyebrow mb-4 text-primary">HAVE SOMETHING IN MIND?</p><h2 className="section-heading">Let’s build your next big thing.</h2><p className="mt-4 text-muted-foreground">A new idea, a better workflow, or a product ready to grow.</p></div><Button asChild variant="portfolio" size="lg"><Link to="/contact">Start a conversation <ArrowUpRight /></Link></Button></div></section>;
}