import { Link } from '@tanstack/react-router';
import { useState } from 'react';
import { ArrowUpRight, Check, BrainCircuit, Database, Search, Workflow } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { projects, services } from '@/lib/portfolio';

export function ExpertiseSection() {
  const [active, setActive] = useState(0);
  const service = services[active] ?? services[0];
  if (!service) return null;
  const project = projects.find(item => item.name === service.example);
  return <section id="services" className="expertise-band"><div className="page-width section">
    <div className="section-top"><div><p className="mono-label mb-4">01 / SERVICES</p><h2 className="section-heading">Services I offer</h2></div></div>
    <div className="service-selector" role="tablist" aria-label="Development services">{services.map((item, i) => <Button key={item.title} variant="ghost" role="tab" id={`service-tab-${i}`} aria-selected={active === i} aria-controls="service-panel" tabIndex={active === i ? 0 : -1} className={active === i ? 'selected' : ''} onClick={() => setActive(i)} onKeyDown={event => { if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') { event.preventDefault(); const next = (active + (event.key === 'ArrowRight' ? 1 : -1) + services.length) % services.length; setActive(next); document.getElementById(`service-tab-${next}`)?.focus(); } }}>{item.label}</Button>)}</div>
    <div className="service-spotlight" role="tabpanel" id="service-panel" aria-labelledby={`service-tab-${active}`}><div className="service-spotlight-copy"><h3>{service.title}</h3><p>{service.description}</p><ul>{service.points.map(point => <li key={point}><Check size={16} />{point}</li>)}</ul><Button asChild variant="portfolio" size="lg"><Link to="/" hash="contact">Discuss your project <ArrowUpRight /></Link></Button></div>{project ? <Button variant="ghost" asChild className="service-screen"><a href={project.url} target="_blank" rel="noopener noreferrer" aria-label={`View ${project.name} live project`}><img src={project.image} alt={`${project.name} dashboard`} /><span>{project.name}<ArrowUpRight size={18} /></span></a></Button> : <div className="ai-workflow" aria-label="AI integration workflow"><BrainCircuit size={42} className="text-accent" /><h4>AI inside your existing system</h4><div className="ai-workflow-steps">{[{ Icon: Database, title: 'Data entry' }, { Icon: Search, title: 'Intelligent search' }, { Icon: Workflow, title: 'Workflow suggestions' }].map(({ Icon, title }) => <div key={title}><Icon size={22} /><span>{title}</span></div>)}</div><span className="text-sm text-muted-foreground">OpenAI API · CRM · Business applications</span></div>}</div>
  </div></section>;
}
