import { useState } from 'react';
import { ArrowUpRight, Check, Loader2, MessageSquare } from 'lucide-react';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';

const inquirySchema = z.object({
  name: z.string().trim().min(1, 'Please enter your name').max(100),
  email: z.string().trim().email('Please enter a valid email').max(255),
  project_type: z.string().trim().min(1).max(100),
  message: z.string().trim().min(10, 'Please share a little more about your project').max(2000),
});

export function InquirySection() {
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const parsed = inquirySchema.safeParse({
      name: data.get('name'),
      email: data.get('email'),
      project_type: data.get('type'),
      message: data.get('message'),
    });
    if (!parsed.success) {
      setStatus('error');
      setErrorMessage(parsed.error.issues[0]?.message ?? 'Please check the form and try again.');
      return;
    }
    setStatus('sending');
    setErrorMessage('');
    const { error } = await supabase.from('inquiries').insert(parsed.data);
    if (error) {
      setStatus('error');
      setErrorMessage('Something went wrong while sending. Please try again.');
      return;
    }
    setStatus('sent');
  }

  return (
    <section id="contact" className="contact-band">
      <div className="page-width section grid gap-12 lg:grid-cols-2">
        <div>
          <p className="eyebrow mb-5 text-primary">LET’S MAKE SOMETHING GREAT</p>
          <h2 className="section-heading">
            Your next chapter
            <br />
            starts with an idea.
          </h2>
          <p className="mt-6 max-w-md leading-7 text-muted-foreground">
            A web app, a custom CRM, or your next SaaS product. Tell me what you have in mind.
          </p>
          <div className="mt-10 flex items-center gap-4 border-t border-border pt-6">
            <MessageSquare className="text-primary" size={26} />
            <div>
              <p className="text-sm font-semibold">Project inquiries</p>
              <p className="mt-1 text-sm text-muted-foreground">I usually reply within one working day.</p>
            </div>
          </div>
        </div>
        <div>
          {status === 'sent' ? (
            <div className="rounded-md border border-border bg-card p-7">
              <p className="eyebrow text-primary">
                <Check size={15} />
                INQUIRY SENT
              </p>
              <h2 className="mt-5 text-2xl font-semibold">Thank you — message received.</h2>
              <p className="mt-4 text-sm leading-7 text-muted-foreground">
                Your inquiry has been sent successfully. I’ll get back to you shortly with next steps.
              </p>
              <Button variant="outline" className="mt-6" onClick={() => setStatus('idle')}>
                Send another inquiry
              </Button>
            </div>
          ) : (
            <form className="space-y-5" onSubmit={handleSubmit}>
              <div className="grid gap-5 sm:grid-cols-2">
                <label className="block text-sm font-medium">
                  Your name
                  <input name="name" required className="inquiry-input mt-2" placeholder="Full name" autoComplete="name" />
                </label>
                <label className="block text-sm font-medium">
                  Email address
                  <input name="email" type="email" required className="inquiry-input mt-2" placeholder="you@company.com" autoComplete="email" />
                </label>
              </div>
              <label className="block text-sm font-medium">
                What are you building?
                <select name="type" className="inquiry-input mt-2" defaultValue="Web application">
                  <option>Web application</option>
                  <option>CRM platform</option>
                  <option>SaaS product</option>
                  <option>AI integration</option>
                  <option>API integration & automation</option>
                  <option>Something else</option>
                </select>
              </label>
              <label className="block text-sm font-medium">
                A little about your project
                <textarea name="message" required className="inquiry-input mt-2 min-h-40 resize-y" placeholder="Your idea, your goals, and where you are today…" />
              </label>
              {status === 'error' && <p className="text-sm text-destructive">{errorMessage}</p>}
              <Button variant="portfolio" size="lg" type="submit" disabled={status === 'sending'}>
                {status === 'sending' ? (
                  <>
                    Sending <Loader2 className="animate-spin" />
                  </>
                ) : (
                  <>
                    Send inquiry <ArrowUpRight />
                  </>
                )}
              </Button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
