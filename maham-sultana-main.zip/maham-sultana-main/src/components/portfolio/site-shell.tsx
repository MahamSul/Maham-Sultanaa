import { Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { ArrowUpRight, ArrowUp, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const navigation = [{ id: 'home', text: 'Home' }, { id: 'projects', text: 'Work' }, { id: 'about', text: 'About' }, { id: 'services', text: 'Services' }] as const;
export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('home');
  useEffect(() => {
    const observer = new IntersectionObserver(entries => { entries.forEach(entry => { if (entry.isIntersecting) setActive(entry.target.id); }); }, { rootMargin: '-15% 0px -55% 0px' });
    document.querySelectorAll('main section[id]').forEach(section => observer.observe(section));
    return () => observer.disconnect();
  }, []);
  return <header className="portfolio-header border-b border-border bg-background/95"><div className="page-width site-header">
    <Link to="/" className="wordmark" aria-label="Maham Sultana home"><span className="brand-mark">m.</span><span>maham<span className="text-primary">.</span></span></Link>
    <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">{navigation.map(n => <Link key={n.id} to="/" hash={n.id} className={`nav-link ${active === n.id ? 'is-active' : ''}`} aria-current={active === n.id ? 'location' : undefined}>{n.text}</Link>)}</nav>
    <div className="flex items-center gap-2"><Button asChild variant="portfolio" className="hidden sm:inline-flex"><Link to="/" hash="contact">Let’s talk <ArrowUpRight /></Link></Button><Button variant="ghost" size="icon" className="md:hidden" aria-label={open ? 'Close navigation' : 'Open navigation'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button></div>
  </div>{open && <nav className="absolute top-full flex w-full flex-col gap-5 border-b border-border bg-background p-6 md:hidden" aria-label="Mobile navigation">{navigation.map(n => <Link key={n.id} to="/" hash={n.id} className="nav-link" onClick={() => setOpen(false)}>{n.text}</Link>)}<Link to="/" hash="contact" onClick={() => setOpen(false)}>Let’s talk ↗</Link></nav>}</header>;
}
export function SiteFooter() {
  return <footer className="border-t border-border"><div className="page-width flex flex-wrap items-center justify-between gap-5 py-8 text-xs text-muted-foreground"><span>© {new Date().getFullYear()} Maham Sultana</span><span>Thoughtfully designed. Carefully developed.</span><Button asChild variant="ghost" size="icon"><Link to="/" hash="home" aria-label="Back to top"><ArrowUp /></Link></Button></div></footer>;
}