import { ArrowUpRight } from 'lucide-react';
import { projects } from '@/lib/portfolio';

export function ProjectGrid({ items = projects }: { items?: typeof projects }) {
  return <div className="grid gap-x-8 gap-y-12 md:grid-cols-2">{items.map((project) => { const Item = project.concept ? 'div' : 'a'; return <Item href={project.concept ? undefined : project.url} target="_blank" rel="noopener noreferrer" className="project-item group block" key={project.name} aria-label={`${project.name}${project.concept ? ' case study' : ' live project'}`}>
    <div className={`project-visual ${project.color}`}><img className="project-image" src={project.image} alt={`${project.name} interface preview`} loading="lazy" /></div>
    <div className="mt-6 flex items-start justify-between gap-4"><div><p className="text-[10px] font-semibold tracking-[1.5px] text-muted-foreground">{project.label}</p><h3 className="mt-2 text-2xl font-semibold">{project.name}</h3></div><span className="flex size-10 shrink-0 items-center justify-center rounded-full border border-border transition-colors group-hover:bg-secondary"><ArrowUpRight size={19} /></span></div>
    <p className="mt-3 max-w-lg text-sm leading-6 text-muted-foreground">{project.description}</p><div className="mt-4 flex flex-wrap gap-2">{project.tags.map(tag => <span key={tag} className="tag">{tag}</span>)}</div>
  </Item>; })}</div>;
}