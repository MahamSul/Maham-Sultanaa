<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep shared navigation and footer in the root layout; portfolio content lives on one scrolling homepage, with legacy page URLs redirecting to matching anchors to preserve links.
- Keep project data and metadata helpers in a shared browser-safe module so project cards remain consistent across pages.
- Model concept projects explicitly in shared portfolio data and omit live-project links for them, so mockups cannot be mistaken for delivered work.
- Keep the interactive services section in a dedicated browser-safe component, deriving its selectable offerings and project examples from shared portfolio data to avoid divergent service details.
- Define categorized developer skills in shared portfolio data and associate service examples by project name, allowing services without a verified project to show a conceptual workflow rather than imply unsupported project capabilities.
- Present technical skills and working approach as separate homepage bands, using shared skill data and global semantic gradient tokens so each section has a clear hierarchy.
- Use CDN asset pointers for portraits and authentic project screenshots to avoid storing media binaries in source control.
- Contact inquiries remain explicit, unsent drafts until the portfolio owner supplies a real contact destination; never imply delivery without an integration.
