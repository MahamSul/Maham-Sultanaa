# Maham Sultana

You have to make a website like this, you dont have to follow the branding and all you can use other colors but i am telling you the niche and projects , i m also attaching the project links
NICHE: Full Stack Web Apps | CRM & SaaS Developer | React, Node.js & Next.js
PROJECT LINKS:
HEALTHCARE:
https://lunex-healthcare.vercel.app/





REAL ESTATE:

https://homiq-realestate.vercel.app/




PROJECT MGMT:




https://flowspace-projectmanagement.vercel.app/




LEAD GEN:

https://lead-management-system-self-nine.vercel.app/


WEBSITE REFERENCE: https://bushra-khan.lovable.app

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/f591aba8-0bab-425d-8ce4-0f238d05e3fd).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
